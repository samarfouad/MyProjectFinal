package com.example.myproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.example.myproject.databinding.FragmentShowitenBookBinding;

public class showitenBook extends Fragment {

    public FragmentShowitenBookBinding binding;
    private Book currentBook;

    public showitenBook() {
        // Required empty public constructor
    }

    public static showitenBook newInstance(String param1, String param2) {
        return new showitenBook();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentShowitenBookBinding.inflate(inflater, container, false);

        if (currentBook != null) {
            displayBookDetails(currentBook);
        }

        return binding.getRoot();
    }

    public void updateBookDetails(Book book) {
        this.currentBook = book;

        if (binding != null) {
            displayBookDetails(book);
        }
    }

    private void displayBookDetails(Book book) {
        binding.textView1.setText(book.getTitle());
        binding.textView2.setText(book.getAuthors());
        binding.textView3.setText(book.getPublisher());
        binding.textView4.setText(book.getPublishedDate());
        binding.textView5.setText(book.getDescription());

        Glide.with(requireContext())
                .load(book.getThumbnailUrl())
                .placeholder(R.drawable.default_book_thumbnail)
                .into(binding.imageView);
    }
}
