package com.example.myproject;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myproject.databinding.ActivityItemBookBinding;

import java.util.List;
public class rvAdapter extends RecyclerView.Adapter<rvAdapter.ViewHolder> {

    private List<Book> bookList;
    private OnItemClickListener listener;

    // واجهة الاستماع للضغط
    public interface OnItemClickListener {
        void onItemClick(Book book);
    }

    public rvAdapter(List<Book> bookList, OnItemClickListener listener) {
        this.bookList = bookList;
        this.listener = listener;
    }

    public rvAdapter(List<Book> bookList) {
        this.bookList = bookList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ActivityItemBookBinding bindingItem = ActivityItemBookBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(bindingItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Book currentBook = bookList.get(position);

        holder.bindingItem.bookTitle.setText(currentBook.getTitle());
        holder.bindingItem.bookAuthors.setText(currentBook.getAuthors());
        holder.bindingItem.bookPublisher.setText(currentBook.getPublisher());
        holder.bindingItem.bookPublishedDate.setText(currentBook.getPublishedDate());
        holder.bindingItem.bookDescription.setText(currentBook.getDescription());

//        Log.v("ThumbnailUrl", currentBook.getThumbnailUrl());

        Glide.with(holder.itemView.getContext())
                .load(currentBook.getThumbnailUrl())
                .placeholder(R.drawable.default_book_thumbnail)
                .into(holder.bindingItem.bookThumbnail);

        holder.bind(currentBook, listener);

//        new LoadImage(holder.binding.bookThumbnail).execute(currentBook.getThumbnailUrl());
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ActivityItemBookBinding bindingItem;

        public ViewHolder(View itemView) {
            super(itemView);
        }
        public void bind(Book book, OnItemClickListener listener) {
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onItemClick(book);
                }
            });
        }
        public ViewHolder(ActivityItemBookBinding binding) {
            super(binding.getRoot());
            this.bindingItem = binding;
        }
    }
}