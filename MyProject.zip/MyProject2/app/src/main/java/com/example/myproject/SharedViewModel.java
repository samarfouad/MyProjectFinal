package com.example.myproject;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

public class SharedViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Book>> bookListLiveData = new MutableLiveData<>();

    public void setBookList(ArrayList<Book> list) {
        bookListLiveData.setValue(list);
    }

    public LiveData<ArrayList<Book>> getBookList() {
        return bookListLiveData;
    }
}