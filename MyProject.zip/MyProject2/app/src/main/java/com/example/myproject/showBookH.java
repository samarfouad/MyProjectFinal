package com.example.myproject;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.example.myproject.databinding.ActivityMainBinding;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.net.HttpURLConnection;
import java.util.ArrayList;

public class showBookH extends AppCompatActivity implements ShowAllBook.OnBookSelectedListener {
    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private PagerAdapter pagerAdapter;
    private ShowAllBook showAllBookFragment;
    private showitenBook showItemBookFragment;
    private boolean isTab2Enabled = false;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_book_h);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewPager2);

        showAllBookFragment = new ShowAllBook();
        showItemBookFragment = new showitenBook();

        pagerAdapter = new PagerAdapter(this);
        viewPager.setAdapter(pagerAdapter);

        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> {
                    if (position == 0) {
                        tab.setText("كتب تفسير القرأن الكريم");
                    } else {
                            tab.setText("تفاصيل الكتاب");
                    }
                }).attach();
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 1 && !isTab2Enabled) {
                    tabLayout.selectTab(tabLayout.getTabAt(0));
                }
            }

            @Override public void onTabUnselected(TabLayout.Tab tab) { }
            @Override public void onTabReselected(TabLayout.Tab tab) { }
        });
    }
    public void enableTab2AndGo() {
        isTab2Enabled = true;
        viewPager.setCurrentItem(1, true);
    }
    @Override
    public void onBookSelected(Book book) {
        showItemBookFragment.updateBookDetails(book);
        isTab2Enabled = true;
        viewPager.setCurrentItem(1, true);
    }
    public class PagerAdapter extends FragmentStateAdapter {
        public PagerAdapter(@NonNull FragmentActivity fragmentActivity) {
            super(fragmentActivity);
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            switch (position) {
                case 0:
                    return showAllBookFragment;
                case 1:
                    return showItemBookFragment;
                default:
                    return new Fragment();
            }
        }

        @Override
        public int getItemCount() {
            return 2;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.item_setting){
            showDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void showDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("عــن التــطبيـق :");
        builder.setMessage("هذا التطبيق يتيح لك البحث وعرض مجموعة من"+
                " كتب تفسير القرآن الكريم بطريقة سهلة وبسيطة" +
                "\n" +
                "\n" +
                "يعتمد التطبيق على واجهة(BooKAPI) لعرض الكتب مباشرة من المصدر" +
                " مما يوفّر لك تجربة قراءة محدثة ودقيقة" +
                "\n" +
                "\n" +
                "مــيزات التــطبيـق:"+
                "\n" +
                "\n" +
                "1- تصفح كتب تفسير متعددة." +
                "\n" +
                "\n" +
                "2- عرض تفاصيل كل كتاب بشكل منفصل." +
                "\n" +
                "\n" +
                "3- واجهة بسيطة وسهلة الاستخدام." +
                "\n" +
                "\n" +
                "4- هذا التطبيق  قيمة لكل من يرغب في التعمق في فهم" +
                " القرآن الكريم من خلال كتب تفسير القرأن الكريم.");
        builder.setPositiveButton("تــم", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}


