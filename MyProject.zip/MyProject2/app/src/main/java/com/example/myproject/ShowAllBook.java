package com.example.myproject;

import static androidx.core.content.ContextCompat.getSystemService;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;


import android.telecom.DisconnectCause;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.myproject.databinding.ActivityMainBinding;
import com.example.myproject.databinding.FragmentShowAllBookBinding;
import com.google.android.material.snackbar.Snackbar;

public class ShowAllBook extends Fragment {
    private NotificationManager notificationManager;

    public static final String CHANNEL_ID = "primary_channel";
    public static final int NOTIFICATION_ID = 0;

    public static FragmentShowAllBookBinding bindingShow;
    OnBookSelectedListener callback;
    public interface OnBookSelectedListener {
        void onBookSelected(Book book);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnBookSelectedListener) {
            callback = (OnBookSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnBookSelectedListener");
        }
    }
    public ShowAllBook newInstance() {
        return new ShowAllBook();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        bindingShow = FragmentShowAllBookBinding.inflate(inflater, container, false);
        notificationManager = (NotificationManager) requireContext().getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel();
        if (isNetworkConnected()) {
            bindingShow.searchEdit.setText("تفسير سور الفرأن");
            new FechBook(requireContext()).execute(bindingShow.searchEdit.getText().toString());
            bindingShow.searchEdit.setText("");
            bindingShow.search.setEnabled(false);
            bindingShow.search.setBackgroundColor(Color.parseColor("#9D795E"));
            bindingShow.search.setTextColor(Color.parseColor("#C4FAD0B4"));
        }
        textWatcher(bindingShow.searchEdit, bindingShow.search);
        bindingShow.search.setOnClickListener(view1 -> {
            if (isNetworkConnected()) {
                new FechBook(requireContext()).execute(bindingShow.searchEdit.getText().toString());
            } else {
                Snackbar.make(view1, "تأكد من اتصالك بالانترنت!",
                        Snackbar.LENGTH_SHORT).show();
                Notification myNot = new NotificationCompat.Builder(requireContext(), CHANNEL_ID)
                        .setSmallIcon(R.drawable.contract)
                        .setContentTitle("تم فحص اتصالك بالانترنت")
                        .setContentText("لم يتم التحميل لعدم وجود اتصال بالانترنت")
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true)
                        .build();
                notificationManager.notify(NOTIFICATION_ID, myNot);
            }
        });
        return bindingShow.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    public boolean isNetworkConnected() {
        ConnectivityManager connMgr = (ConnectivityManager)
                requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = null;
        if (connMgr != null) {
            networkInfo = connMgr.getActiveNetworkInfo();
        }
        return networkInfo != null && networkInfo.isConnected();
    }

    public static void textWatcher(EditText editText, Button button) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    button.setEnabled(true);
                    button.setBackgroundColor(Color.parseColor("#BC5D03"));
                    button.setTextColor(Color.parseColor("#FDEEA1"));
                } else {
                    button.setEnabled(false);
                    button.setBackgroundColor(Color.parseColor("#9D795E"));
                    button.setTextColor(Color.parseColor("#C4FAD0B4"));

                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
    public void createChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.
                os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new
                    NotificationChannel(
                    CHANNEL_ID,
                    "Primary Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            notificationManager.createNotificationChannel
                    (channel);
        }
    }

}