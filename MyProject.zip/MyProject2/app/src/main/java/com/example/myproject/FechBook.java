package com.example.myproject;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.AsyncTask;
import android.view.View;

import androidx.core.app.NotificationCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.*;

public class FechBook extends AsyncTask<String , Void, String>{

        final String BASE_URL = "https://books.googleapis.com/books/v1/volumes?";
        final String QUERY = "q";
        final String MAX_RESULTS = "maxResults";
        final String PRINT_TYPE = "printType";

        OkHttpClient client = new OkHttpClient();

    private final Context context;
    private NotificationManager notificationManager;

    public static final String CHANNEL_ID = "primary_channel";
    public static final int NOTIFICATION_ID = 0;
    Context contextt = ShowAllBook.bindingShow.getRoot().getContext();
    Context contexttt = ShowAllBook.bindingShow.getRoot().getContext();
        public static ArrayList<Book> bookList;

    public FechBook(Context context) {
        this.context = context;
    }

    @Override
        protected String doInBackground(String... strings) {

            HttpUrl.Builder builder = HttpUrl.parse(BASE_URL).newBuilder();
            builder.addQueryParameter(QUERY, strings[0])
                    .addQueryParameter(MAX_RESULTS, "25")
                    .addQueryParameter(PRINT_TYPE, "BOOKS");
            String url = builder.build().toString();

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            try {
                Response response = client.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String string) {
            super.onPostExecute(string);

            ShowAllBook.bindingShow.progressBar.setVisibility(View.INVISIBLE);

            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            createNotificationChannel();
            if (string == null || string.isEmpty()) {
                // لا يوجد اتصال أو استجابة فارغة
                Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(R.drawable.contract)
                        .setContentTitle("فـشــل التــحـمــيل!")
                        .setContentText("تأكد من اتصالك من الانترنت")
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true)
                        .build();
                notificationManager.notify(NOTIFICATION_ID, notification);

                Snackbar.make(ShowAllBook.bindingShow.search, "لا يوجد اتصال بالإنترنت", Snackbar.LENGTH_SHORT).show();
                return;
            }

            try {
                JSONObject jsonObject = new JSONObject(string);
                JSONArray itemsArray = jsonObject.getJSONArray("items");

                bookList = new ArrayList<>();

                for (int i = 0; i < itemsArray.length(); i++) {
                    JSONObject book = itemsArray.getJSONObject(i);
                    JSONObject volumeInfo = book.getJSONObject("volumeInfo");
                    JSONObject imageLinks = volumeInfo.getJSONObject("imageLinks");

                    try {
                        bookList.add(new Book(
                                book.getString("id"),
//                            imageLinks.getString("thumbnail"),
                                "http://books.google.com/books/content?id="
                                        + book.getString("id")
                                        + "&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api",
                                volumeInfo.getString("title"),
                                volumeInfo.getString("authors"),
                                volumeInfo.getString("publisher"),
                                volumeInfo.getString("publishedDate"),
                                volumeInfo.getString("description")
                        ));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                if (bookList.size() > 0) {
                    if (!bookList.isEmpty()) {
                        // عرض الإشعار
                        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                                .setSmallIcon(R.drawable.contract)
                                .setContentTitle("تم التحميل بنجاح")
                                .setContentText("تـم عـرض الكـتـب بـنـجـاح")
                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                .setAutoCancel(true)
                                .build();
                        notificationManager.notify(NOTIFICATION_ID, notification);

                        ShowAllBook.bindingShow.progressBar.setVisibility(View.INVISIBLE);
                        rvAdapter bookListAdapter = new rvAdapter(bookList, book -> {
                            if (ShowAllBook.bindingShow != null && ShowAllBook.bindingShow.getRoot().getContext() instanceof ShowAllBook.OnBookSelectedListener) {
                                ShowAllBook.OnBookSelectedListener listener = (ShowAllBook.OnBookSelectedListener) ShowAllBook.bindingShow.getRoot().getContext();
                                listener.onBookSelected(book);
                            }
                        });
                        ShowAllBook.bindingShow.recyclerView1.setAdapter(bookListAdapter);
                        ShowAllBook.bindingShow.recyclerView1.setLayoutManager(
                                new LinearLayoutManager(contextt));
                    }
                } else {
                    ShowAllBook.bindingShow.progressBar.setVisibility(View.INVISIBLE);
                    Snackbar.make(ShowAllBook.bindingShow.search, "لا يوجد كتب", Snackbar.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                ShowAllBook.bindingShow.progressBar.setVisibility(View.INVISIBLE);
                Snackbar.make(ShowAllBook.bindingShow.search, "لا يوجد كتب", Snackbar.LENGTH_SHORT).show();
                e.printStackTrace();
            }
            //if (bookList != null && bookList.size() > 0) {
                //SharedViewModel viewModel = new ViewModelProvider(context).get(SharedViewModel.class);
              //  viewModel.setBookList(bookList);
            //}
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            ShowAllBook.bindingShow.progressBar.setVisibility(View.VISIBLE);
        }
        public static ArrayList<Book> sentArray(){
            return bookList;
        }
    private void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "تنبيهات الكتب",
                    NotificationManager.IMPORTANCE_HIGH
            );
            notificationManager.createNotificationChannel(channel);
        }
    }
}
